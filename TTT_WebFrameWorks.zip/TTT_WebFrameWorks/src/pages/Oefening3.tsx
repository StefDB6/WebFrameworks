import Counter from "../Components/Counter";


const Oefening3 = () => {

    return (
        <>
            <Counter/>
        </>
    )
}

export default Oefening3;